#!/bin/bash

find . -type f -exec nkf -s -Lw --overwrite {} \;
