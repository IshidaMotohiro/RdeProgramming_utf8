# 3  2013 01  25

#  dot.Rprofile.txt 
RWindowsC:/Users/Mac /Users/
.Rrofile 
Windowsdot.Rprofile.txt .Rrofile 
Macdot.Rprofile.txt/Users/


mv  dot.Profile  .Profile




# 3

 zipAozora_Win.R Windows Aozora_UTF8.R Mac
 zipURLAozoraURL.R Windows AozoraURL8.R Mac

2


script
Aozora_Win.R Windows Aozora_UTF8.R Mac


 source() 


 source("C:/Users/ishida/Documents/data/script/Aozora_UTF8.R")

 Aozora ("C:/Users/ishida/Documents/data/")


 "-u.txt"  "-w.txt" 




script
AozoraURL.R Windows AozoraURL8.R Mac


 source() 



source ("AozoraURL8.R")
Aozora ("http://www.aozora.gr.jp/cards/000129/files/42375_ruby_18247.zip", "Ougai_Niwatori.txt") 



NORUBY






# A.2
 Github 
Shift-JIS
UTF-8
UTF-8RStudio
26UTF-8


FirstProject01/User/ishida
script CP932toUTF8.sh 


  cd ~
  chmod 755 CP932toUTF8.sh
  ./CP932toUTF8.sh


