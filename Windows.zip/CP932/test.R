getwd ()

setwd ("D:/data") # Ddata

1 + 2

install.packages ("rgl")
library (rgl)

demo (rgl)
